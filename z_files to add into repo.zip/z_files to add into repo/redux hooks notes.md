Here are the correct and concise points on React Redux hooks and their usage with examples:

### Introduction

- **React Redux Hooks**: React Redux offers a set of hooks as an alternative to the existing `connect()` Higher-Order Component.
- **useDispatch**: A hook that allows functional components to dispatch actions to the Redux store.
- **useSelector**: A hook that allows functional components to extract and access data from the Redux store.

### Using useDispatch

- **Import**: Import the `useDispatch` hook from `react-redux`.
- **Usage**: Call `useDispatch` within your functional component to get a reference to the dispatch function.
- **Dispatch Function**: Use the dispatch function to dispatch actions to the Redux store.

### Using useSelector

- **Import**: Import the `useSelector` hook from `react-redux`.
- **Usage**: Call `useSelector` within your functional component, passing in a selector function.
- **Selector Function**: Define which part of the Redux store state you want to extract and use within your component.
- **Returns**: Returns the selected data from the Redux store, which you can then use within your component.

### Example Code

```jsx
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updateFirstName } from '../redux/actions';

const Form = () => {
  const dispatch = useDispatch();
  const nameObj = useSelector((state) => state.nameReducer);
  const { firstName } = nameObj;

  const handleFirstName = () => {
    dispatch(updateFirstName('Jason'));
  };

  return (
    <React.Fragment>
      <div className="container">
        <label>First Name: {firstName}</label>
        <button onClick={handleFirstName}>Update First Name</button>
      </div>
    </React.Fragment>
  );
};

export default Form;
```

### Other Hooks

- **useActions**: This hook was removed in v7.1.0, but you can manually bind action creators using `bindActionCreators` or create custom hooks.
- **useShallowEqualSelector**: This hook is used to shallowly compare the selector function with the previous state to avoid unnecessary re-renders.

### Conclusion

React Redux hooks provide a cleaner and more efficient way to manage state and dispatch actions in functional components. They simplify the code and improve performance, but require a learning curve and careful usage to avoid performance concerns.

### Additional Tips

- **Use `useDispatch` instead of `connect`**: `useDispatch` is a more lightweight alternative to `connect` and provides better TypeScript support.
- **Use `useSelector` instead of `mapStateToProps`**: `useSelector` is a more straightforward way to access Redux store data without the need for `mapStateToProps`.
- **Keep your components small and focused**: Use hooks to manage state and actions within your components, keeping them small and easy to maintain.

### Example of Custom Context

```jsx
import React from 'react';
import { createContext, useContext } from 'react';
import { createStoreHook, createDispatchHook, createSelectorHook } from 'react-redux';

const MyContext = React.createContext(null);

const useStore = createStoreHook(MyContext);
const useDispatch = createDispatchHook(MyContext);
const useSelector = createSelectorHook(MyContext);

const myStore = createStore(rootReducer);

const MyProvider = ({ children }) => {
  return (
    <Provider context={MyContext} store={myStore}>
      {children}
    </Provider>
  );
};
```

### Example of Custom Hook

```jsx
import React from 'react';
import { useMemo } from 'react';
import { useDispatch } from 'react-redux';

export function useActions(actions, deps) {
  const dispatch = useDispatch();
  return useMemo(() => {
    if (Array.isArray(actions)) {
      return actions.map((a) => bindActionCreators(a, dispatch));
    }
    return bindActionCreators(actions, dispatch);
  }, deps);
}
```

### Example of useActions Hook

```jsx
import React from 'react';
import { useDispatch } from 'react-redux';
import { updateFirstName } from '../redux/actions';

const Form = () => {
  const dispatch = useDispatch();

  const handleFirstName = () => {
    dispatch(updateFirstName('Jason'));
  };

  return (
    <React.Fragment>
      <div className="container">
        <label>First Name: {firstName}</label>
        <button onClick={handleFirstName}>Update First Name</button>
      </div>
    </React.Fragment>
  );
};
```

### Example of useShallowEqualSelector Hook

```jsx
import React from 'react';
import { useSelector, shallowEqual } from 'react-redux';

export function useShallowEqualSelector(selector) {
  return useSelector(selector, shallowEqual);
}
```

### Conclusion

React Redux hooks provide a powerful and flexible way to manage state and actions in functional components. By using these hooks, you can create cleaner, more maintainable code that is easier to understand and debug.

Citations:
[1] https://blog.logrocket.com/react-hooks-vs-redux-hooks-context-replace-redux/
[2] https://thoughtbot.com/blog/using-redux-with-react-hooks
[3] https://react-redux.js.org/api/hooks
[4] https://dev.to/bangash1996/introduction-react-redux-using-hooks-useselector-usedispatch-26ch
[5] https://www.memberstack.com/blog/react-redux-hooks-useselector-usedispatch