Here are the correct and concise points on React Hooks and their usage with examples:

### Introduction

- **React Hooks**: React Hooks are methods that allow functional components to use state and other React features without writing a class component.
- **Common React Hooks**:
  - **useState**: Used to manage state in functional components.
  - **useReducer**: Used to manage complex state in functional components.
  - **useEffect**: Used to handle side effects in functional components.
  - **useLayoutEffect**: Used to handle side effects before the page is rendered.
  - **useCallback**: Used to memoize functions in functional components.
  - **useMemo**: Used to memoize values in functional components.
  - **useContext**: Used to access context in functional components.
  - **useRef**: Used to create a reference to a DOM node or a value that persists across renders.
  - **useImperativeHandle**: Used to customize the instance value that is exposed to parent components when using `ref`.

### Using useState

- **Import**: Import the `useState` hook from `react`.
- **Usage**: Call `useState` within your functional component, passing in the initial state value.
- **Returns**: Returns an array with the current state value and a function to update the state.

### Example Code

```jsx
import React, { useState } from 'react';

const Counter = () => {
  const [count, setCount] = useState(0);

  const handleClick = () => {
    setCount(count + 1);
  };

  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={handleClick}>Increment</button>
    </div>
  );
};
```

### Using useReducer

- **Import**: Import the `useReducer` hook from `react`.
- **Usage**: Call `useReducer` within your functional component, passing in the reducer function and the initial state.
- **Returns**: Returns the current state and a function to dispatch actions.

### Example Code

```jsx
import React, { useReducer } from 'react';

const reducer = (state, action) => {
  switch (action.type) {
    case 'INCREMENT':
      return { count: state.count + 1 };
    case 'DECREMENT':
      return { count: state.count - 1 };
    default:
      throw new Error('Unknown action');
  }
};

const Counter = () => {
  const [state, dispatch] = useReducer(reducer, { count: 0 });

  const handleClick = () => {
    dispatch({ type: 'INCREMENT' });
  };

  return (
    <div>
      <p>Count: {state.count}</p>
      <button onClick={handleClick}>Increment</button>
    </div>
  );
};
```

### Using useEffect

- **Import**: Import the `useEffect` hook from `react`.
- **Usage**: Call `useEffect` within your functional component, passing in a function to execute and an array of dependencies.
- **Returns**: Returns nothing.

### Example Code

```jsx
import React, { useEffect } from 'react';

const FetchData = () => {
  useEffect(() => {
    fetch('https://api.example.com/data')
      .then((res) => res.json())
      .then((data) => console.log(data));
  }, []);

  return <div>Data fetched!</div>;
};
```

### Using useLayoutEffect

- **Import**: Import the `useLayoutEffect` hook from `react`.
- **Usage**: Call `useLayoutEffect` within your functional component, passing in a function to execute and an array of dependencies.
- **Returns**: Returns nothing.

### Example Code

```jsx
import React, { useLayoutEffect } from 'react';

const MeasureComponent = () => {
  useLayoutEffect(() => {
    console.log('Layout effect executed');
  }, []);

  return <div>Measure Component</div>;
};
```

### Using useCallback

- **Import**: Import the `useCallback` hook from `react`.
- **Usage**: Call `useCallback` within your functional component, passing in a function to memoize and an array of dependencies.
- **Returns**: Returns the memoized function.

### Example Code

```jsx
import React, { useCallback } from 'react';

const MemoizedFunction = () => {
  const memoizedFunction = useCallback(() => {
    console.log('Memoized function executed');
  }, []);

  return <button onClick={memoizedFunction}>Click me!</button>;
};
```

### Using useMemo

- **Import**: Import the `useMemo` hook from `react`.
- **Usage**: Call `useMemo` within your functional component, passing in a function to memoize and an array of dependencies.
- **Returns**: Returns the memoized value.

### Example Code

```jsx
import React, { useMemo } from 'react';

const MemoizedValue = () => {
  const memoizedValue = useMemo(() => {
    console.log('Memoized value calculated');
    return 42;
  }, []);

  return <p>Memoized value: {memoizedValue}</p>;
};
```

### Using useContext

- **Import**: Import the `useContext` hook from `react`.
- **Usage**: Call `useContext` within your functional component, passing in the context object.
- **Returns**: Returns the context value.

### Example Code

```jsx
import React, { useContext } from 'react';

const ThemeContext = React.createContext('light');

const ThemeProvider = ({ children }) => {
  return (
    <ThemeContext.Provider value="dark">
      {children}
    </ThemeContext.Provider>
  );
};

const ThemeConsumer = () => {
  const theme = useContext(ThemeContext);

  return <p>Theme: {theme}</p>;
};
```

### Using useRef

- **Import**: Import the `useRef` hook from `react`.
- **Usage**: Call `useRef` within your functional component, passing in an initial value.
- **Returns**: Returns a reference to the DOM node or value.

### Example Code

```jsx
import React, { useRef } from 'react';

const InputField = () => {
  const inputRef = useRef(null);

  const handleClick = () => {
    inputRef.current.focus();
  };

  return (
    <div>
      <input ref={inputRef} type="text" />
      <button onClick={handleClick}>Focus Input</button>
    </div>
  );
};
```

### Using useImperativeHandle

- **Import**: Import the `useImperativeHandle` hook from `react`.
- **Usage**: Call `useImperativeHandle` within your functional component, passing in a reference to the component and a function to customize the instance value.
- **Returns**: Returns nothing.

### Example Code

```jsx
import React, { useRef, useImperativeHandle } from 'react';

const CustomInput = forwardRef((props, ref) => {
  const inputRef = useRef(null);

  useImperativeHandle(ref, () => ({
    focus: () => {
      inputRef.current.focus();
    },
  }));

  return <input ref={inputRef} type="text" />;
});
```

### Conclusion

React Hooks provide a powerful and flexible way to manage state and side effects in functional components. By using these hooks, you can create modular and reusable components that are easier to maintain and debug.