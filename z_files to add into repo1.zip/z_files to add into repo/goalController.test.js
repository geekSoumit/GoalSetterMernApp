const { updateGoal } = require("./goalController");
const Goal = require("../models/Goal");

describe("updateGoal", () => {
  it("should update a goal and return the updated goal", async () => {
    const mockGoal = {
      _id: "goalId",
      user: "userId",
      // other properties
    };

    const mockUpdatedGoal = {
      _id: "goalId",
      user: "userId",
      // updated properties
    };

    const findByIdMock = jest
      .spyOn(Goal, "findById")
      .mockResolvedValue(mockGoal);
    const findByIdAndUpdateMock = jest
      .spyOn(Goal, "findByIdAndUpdate")
      .mockResolvedValue(mockUpdatedGoal);

    const req = {
      params: {
        id: "goalId",
      },
      body: {
        // updated properties
      },
      user: {
        id: "userId",
      },
    };

    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await updateGoal(req, res);

    expect(findByIdMock).toHaveBeenCalledWith("goalId");
    expect(findByIdAndUpdateMock).toHaveBeenCalledWith("goalId", req.body, {
      new: true,
    });
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(mockUpdatedGoal);
  });

  it("should throw an error if the goal is not found", async () => {
    const findByIdMock = jest.spyOn(Goal, "findById").mockResolvedValue(null);

    const req = {
      params: {
        id: "goalId",
      },
    };

    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await expect(updateGoal(req, res)).rejects.toThrow("Goal not found");
    expect(findByIdMock).toHaveBeenCalledWith("goalId");
    expect(res.status).toHaveBeenCalledWith(400);
  });

  it("should throw an error if the user is not found", async () => {
    const mockGoal = {
      _id: "goalId",
      user: "userId",
      // other properties
    };

    const findByIdMock = jest
      .spyOn(Goal, "findById")
      .mockResolvedValue(mockGoal);

    const req = {
      params: {
        id: "goalId",
      },
      user: null,
    };

    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await expect(updateGoal(req, res)).rejects.toThrow("User not found");
    expect(findByIdMock).toHaveBeenCalledWith("goalId");
    expect(res.status).toHaveBeenCalledWith(401);
  });

  it("should throw an error if the user is not authorized", async () => {
    const mockGoal = {
      _id: "goalId",
      user: "otherUserId",
      // other properties
    };

    const findByIdMock = jest
      .spyOn(Goal, "findById")
      .mockResolvedValue(mockGoal);

    const req = {
      params: {
        id: "goalId",
      },
      user: {
        id: "userId",
      },
    };

    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await expect(updateGoal(req, res)).rejects.toThrow(
      "User is not authorized to do this action!"
    );
    expect(findByIdMock).toHaveBeenCalledWith("goalId");
    expect(res.status).toHaveBeenCalledWith(401);
  });
});
describe("getGoals", () => {
  it("should return all goals for a user", async () => {
    const mockGoals = [
      {
        _id: "goalId1",
        user: "userId",
        // other properties
      },
      {
        _id: "goalId2",
        user: "userId",
        // other properties
      },
    ];

    const findMock = jest.spyOn(Goal, "find").mockResolvedValue(mockGoals);

    const req = {
      user: {
        id: "userId",
      },
    };

    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await getGoals(req, res);

    expect(findMock).toHaveBeenCalledWith({ user: "userId" });
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(mockGoals);
  });

  it("should return an empty array if no goals found for a user", async () => {
    const findMock = jest.spyOn(Goal, "find").mockResolvedValue([]);

    const req = {
      user: {
        id: "userId",
      },
    };

    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await getGoals(req, res);

    expect(findMock).toHaveBeenCalledWith({ user: "userId" });
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith([]);
  });

  it("should throw an error if user id is not provided", async () => {
    const req = {
      user: null,
    };

    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await expect(getGoals(req, res)).rejects.toThrow("User ID not provided");
    expect(res.status).toHaveBeenCalledWith(400);
  });
});
